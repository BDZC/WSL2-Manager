﻿namespace WslManager.Structures
{
    public enum OrderTypes
    {
        None = 0,
        DistroName,
        DistroType,
        DistroStatus,
    }
}
